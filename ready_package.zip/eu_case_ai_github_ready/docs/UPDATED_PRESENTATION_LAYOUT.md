# Updated Presentation Layout

## Slide 1 — Title

**Local AI-Assisted Legal-Linguistic Case-Law Analysis**  
**From manual case searching to a structured local archive, keyword lists, reports, and translation**

Speaker note: This presentation explains the tool, the original aim, the current achievement, and the revised workflow. The intended audience is legal linguists rather than programmers.

---

## Slide 2 — The Research Problem

Manual legal-linguistic case research is slow because the same steps must be repeated for every case:

- finding relevant public case-law documents,
- saving them in usable form,
- extracting text,
- checking dates and document types,
- searching for linguistic issues,
- preparing case summaries,
- translating results.

Speaker note: The problem is not the absence of public data. The problem is that public data is scattered and the preparatory work takes too long.

---

## Slide 3 — Initial Aim

The initial aim was to create a local AI-supported workflow that could:

1. download public CURIA case documents,
2. store them locally,
3. search them by language-related keywords,
4. identify relevant cases,
5. generate concise legal-linguistic reports,
6. translate selected reports into EU official languages.

Speaker note: The tool was planned as a local system because legal-linguistic research often benefits from reproducibility, privacy, and stable access to source documents.

---

## Slide 4 — What Was Achieved

The prototype now automates the slowest preparatory steps:

| Task | Previous method | Current prototype |
|---|---|---|
| Collect cases | manual browser search | year-range CURIA collector |
| Store documents | scattered files | structured local archive |
| Search | repeated manual keyword search | SQLite keyword search |
| Case list | manually typed list | Word + JSON + CSV output |
| Report | manual first draft | local model-assisted report |
| Translation | separate manual step | integrated translation step |

Speaker note: The most important achievement is not full automation of legal reasoning. It is the automation of the repetitive preparation stage.

---

## Slide 5 — Why This Matters for Linguistic Work

The tool is useful because it separates:

**Mechanical filtering**  
Dates, document types, keywords, and local availability.

**Interpretive analysis**  
Language variation, ambiguity, legal meaning, and significance.

Speaker note: A language model is not needed for every step. The tool only calls the model when a contextual report is requested.

---

## Slide 6 — The Main Workflow

1. Bulk collect public CURIA pages for a year range.
2. Ingest the saved HTML/PDF/text into a local archive.
3. Specify date and optional criteria.
4. Enter keywords.
5. Choose whether all keywords or any keyword must appear.
6. Generate a keyword case list.
7. Add a short context only if report generation is needed.
8. Generate English reports.
9. Translate selected reports.

Speaker note: The context is deliberately limited to 10 words. This keeps the model task focused.

---

## Slide 7 — The Starting Menu

The tool begins by asking whether the work should proceed from:

1. a new criteria-and-keyword search,
2. a recent keyword case list,
3. an imported keyword case list,
4. a bulk collection step.

Speaker note: This matters because research often resumes from a previous list. The tool does not force the entire process to restart.

---

## Slide 8 — Criteria Logic

The date is checked first.

If the date range is not locally available, the tool reports that the data is not in the local archive and returns to bulk collection.

Other criteria are optional:

- document type,
- judge,
- Advocate General,
- language,
- case number,
- party/name,
- ECLI,
- CELEX.

Speaker note: Leaving a criterion blank means that criterion is not used. A blank judge field includes all judges.

---

## Slide 9 — Keyword List Mode

The keyword list mode does not need a language model.

It creates:

- a Word list for human reading,
- a JSON list for machine use,
- a CSV list for spreadsheet review.

Speaker note: This makes the tool faster and more stable. A simple keyword list should not spend time loading a large model.

---

## Slide 10 — Context-Based Report Mode

If a short context is supplied, report generation becomes available.

Example context:

```text
translation error recovery
```

The user then chooses:

- reports for all cases, or
- reports only for selected cases.

Speaker note: Context is not a second search query. It is a short interpretive lens for the report.

---

## Slide 11 — Report Structure

Each English report follows a consistent structure:

1. Abstract
2. Facts and linguistic problem
3. Procedural and legal context
4. Language variation or terminology issue
5. Method of interpretation
6. Outcome and significance
7. Relevance to the context
8. Source note

Speaker note: This structure follows the legal-linguistic seminar style: problem, context, wording, language variation, analysis, conclusion.

---

## Slide 12 — Translation Layer

After the English report is complete, the tool asks whether translation is required.

The target language may be one EU official language or several.

The report is split into small chunks before translation so that the translation model is less likely to fail.

Speaker note: Translation is deliberately the last step. It is cheaper to translate selected final reports than to translate every candidate case.

---

## Slide 13 — Timeout Problem and Solution

The original 120B model plan was too heavy for rapid testing.

The Windows-safe settings are:

```text
gpt-oss:20b
num_ctx: 8192
think: low
source text per case: 12000 characters
maximum cases per batch: 3
```

Speaker note: These settings are not theoretically maximal. They are practical settings chosen to get reliable runs under time pressure.

---

## Slide 14 — Why Smaller First Is Better

The smaller model is used first to test the method:

- collection,
- ingestion,
- search,
- list generation,
- one report,
- translation.

Once the method works, the larger model can be tested separately.

Speaker note: The model should not be the first source of failure. The archive and workflow should be proven before 120B is used.

---

## Slide 15 — Example Use Case

A keyword search such as:

```text
language version; legal certainty
```

can locate cases where a language version affects legal consequences.

A short context such as:

```text
translation error recovery
```

then guides the report.

Speaker note: This mirrors the On Air / Different Media issue: language version, correction, legal certainty, legitimate expectations, and recovery.

---

## Slide 16 — Conclusion

The project does not automate legal judgment.

It automates the repetitive preparation around legal-linguistic judgment:

- collecting,
- storing,
- searching,
- listing,
- drafting,
- translating.

Speaker note: The value is methodological. The tool makes the research workflow faster, more reproducible, and easier to review.

---

# Technical Appendix Slides

## Appendix A — Components

| Component | Function |
|---|---|
| Playwright | Opens CURIA pages and saves rendered HTML |
| BeautifulSoup | Extracts readable text from HTML |
| SQLite FTS5 | Performs local keyword search |
| Ollama | Runs the local analysis and translation models |
| GPT-OSS 20B | Safe default analysis model |
| TranslateGemma | Default translation model |

---

## Appendix B — Safe Defaults

```yaml
analysis_model: gpt-oss:20b
translation_model: translategemma:27b
num_ctx: 8192
think: low
keep_alive: 0
chunk size: 2200 characters
source per report: 12000 characters
```

---

## Appendix C — Why the Model Does Not Read the Whole Archive

The archive is searched first. Only relevant excerpts are sent to the model.

This reduces:

- runtime,
- memory use,
- hallucination risk,
- unnecessary translation,
- report generation failures.

---

## Appendix D — Current Limitation

The collector may encounter:

- missing CURIA documents,
- robot checks,
- dynamically loaded pages,
- documents not available in a selected language.

The tool records these events in the manifest instead of treating them as fatal errors.

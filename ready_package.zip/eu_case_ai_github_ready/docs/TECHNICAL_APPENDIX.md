# Technical Appendix

## A. Safe Configuration

The default Windows profile is `config.windows.safe.yaml`.

```yaml
analysis_model: "gpt-oss:20b"
translation_model: "translategemma:27b"
num_ctx: 8192
think: "low"
keep_alive: "0"
max_chars: 2200
overlap_chars: 250
source_chars_per_case: 12000
max_cases_per_batch: 3
```

The purpose of this profile is to prevent timeout during prototype testing. It does so by using a smaller analysis model, limiting the context window, reducing chunk size, and generating reports case by case.

## B. Experimental 120B Configuration

The file `config.120b.lowctx.example.yaml` keeps the same low-context strategy but replaces the analysis model with:

```yaml
analysis_model: "gpt-oss:120b"
num_ctx: 8192
think: "low"
source_chars_per_case: 10000
max_cases_per_batch: 2
```

If the model fails before generating any text, the problem is likely model loading rather than the report workflow. In that situation, the smaller profile should be used until local memory allocation is adjusted.

## C. Why 8192 Context Was Chosen

The models may support much larger theoretical context windows. However, the project does not need to send a whole archive into the model. Retrieval is performed first. A practical 8192-token context is enough for a concise report based on selected excerpts and is much less likely to exhaust local resources.

## D. Data Flow

```text
CURIA page -> saved HTML -> extracted text -> SQLite FTS index
           -> keyword list DOCX/JSON/CSV
           -> selected cases + 10-word context
           -> English report
           -> optional EU-language translations
```

## E. SQLite Tables

| Table | Function |
|---|---|
| documents | Stores metadata for each ingested document |
| chunks | Stores smaller text chunks for retrieval |
| chunks_fts | Full-text search index |
| collection_runs | Records year-range collection coverage |
| keyword_lists | Records recent keyword lists for reuse |

## F. Local Models

The analysis model is accessed through Ollama's local HTTP API. The default model is `gpt-oss:20b`. Translation is performed by the configured local translation model, defaulting to `translategemma:27b`.

## G. Report Generation Safeguards

Timeout risk is reduced by the following design choices:

1. No model call is made for a plain keyword list.
2. A context of at most 10 words is used to decide whether report generation is needed.
3. Only selected chunks are passed to the model.
4. Reports are generated one case at a time.
5. `keep_alive` is set to `0` so that models are not unnecessarily kept loaded.
6. `num_ctx` is set to `8192` by default.
7. The safe profile uses `gpt-oss:20b` until the workflow is verified.

## H. Collection Method

The integrated collector uses Playwright/Chromium rather than raw HTTP requests. This is important because public legal pages may be dynamically served or may present robot-check pages. The browser-based collector saves the actual HTML rendered by the page and also stores extracted text.

The collector supports:

- year ranges,
- court prefixes such as C and T,
- language codes,
- maximum case number per year,
- headed browser mode,
- manual challenge handling,
- automatic ingestion into the local archive,
- manifest writing.

## I. Main Commands

```powershell
python -m eu_case_ai setup --overwrite
python -m eu_case_ai doctor
python -m eu_case_ai collect --years 2024-2025 --courts C,T --langs en --headed --manual
python -m eu_case_ai ingest archive\raw\en --lang en
python -m eu_case_ai search --keywords "language version; legal certainty" --match-mode any
python -m eu_case_ai report --list archive\case_lists\keyword_list_NAME.json --context "translation error recovery"
python -m eu_case_ai translate --report reports\en\REPORT.md --targets ro,de,fr
python -m eu_case_ai workflow
```

## J. Recommended Test Order

1. Run `doctor`.
2. Run `model-test`.
3. Ingest one manually saved case.
4. Run keyword search with no context.
5. Generate one English report.
6. Translate one report into one language.
7. Only then run bulk collection or 120B testing.

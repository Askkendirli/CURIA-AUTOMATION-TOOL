# Methodology: Local Legal-Linguistic Case-Law Analysis

## Abstract

This project develops a local workflow for legal-linguistic analysis of EU case law. The initial aim was to reduce the time needed to locate relevant cases, extract usable text, classify documents, and prepare concise reports on language variation, multilingual interpretation, and legal certainty. The achieved prototype streamlines the process by dividing the work into collection, local archiving, keyword list generation, optional context-based report generation, and translation into EU official languages.

The method does not replace legal analysis. It shortens the preparatory stage, preserves source files locally, and creates standardised outputs that can be checked by a researcher.

**Keywords:** legal linguistics, EU multilingualism, CURIA, local archive, keyword search, report generation, translation, Ollama, GPT-OSS, TranslateGemma

## 1. Initial Plan

The original plan was to build a local system that could process freely available EU case-law documents and identify cases where language variation affected legal interpretation. The motivating example was a case involving a Romanian language-version error in the General Block Exemption Regulation, where the terms of the official Romanian text differed from the intended wording and raised questions of legal certainty, legitimate expectations, and recovery of State aid.

The planned workflow had five elements:

| Stage | Intended function | Reason for inclusion |
|---|---|---|
| Source gathering | Download case-law documents from public databases | Avoid repeated manual searching |
| Text extraction | Convert HTML/PDF documents into searchable text | Make the archive usable without OCR |
| Keyword filtering | Locate cases involving relevant words or phrases | Reduce the number of documents sent to a model |
| Context analysis | Use a local model only where a report is needed | Avoid wasting time and memory on simple searches |
| Translation | Translate final reports into EU official languages | Support multilingual presentation and comparison |

## 2. What Was Achieved

The working prototype now automates and streamlines the main preparatory steps:

1. CURIA pages can be collected in bulk by year range, court prefix, and language.
2. Saved HTML files are converted into local text and indexed in SQLite.
3. A search can be performed with one or more keywords.
4. The search can require all keywords or any keyword.
5. Blank criteria are ignored, so the search remains flexible.
6. A result list is produced in Word, JSON, and CSV.
7. If no context is provided, the tool stops after the list and does not call the LLM.
8. If a short context is supplied, reports can be generated for all or selected cases.
9. Reports are generated in English first and translated only when requested.
10. The model, context length, chunk size, and timeout values are configurable.

This is useful because the expensive part of the workflow, namely model-assisted reasoning, is only used after the local archive and keyword list have already narrowed the field.

## 3. Why This Is Good for Legal-Linguistic Work

Manual legal-linguistic research often involves repeated searching, downloading, copying, and comparing. That process is slow and inconsistent. The prototype improves the workflow in three practical ways.

First, it preserves the source material. Each collected case is saved locally as HTML and text, which makes later verification easier.

Secondly, it separates mechanical filtering from interpretive analysis. Keywords, document type, date, court prefix, and other criteria can be checked locally without a language model. This keeps the model for tasks that actually require synthesis.

Thirdly, it standardises the output. The same report structure is used for each case, so different cases can be compared more easily.

## 4. How the Tool Works

The tool begins with a choice between three working modes:

| Mode | Use case |
|---|---|
| Criteria and keywords | A new search is being performed inside the local archive |
| Recent keyword list | A previously generated list is being reused |
| Imported keyword list | A list from another folder or another researcher is being used |

If a new criteria workflow is selected, the date range is checked first. When the requested dates fall outside recorded local collection coverage, the tool reports that the local archive does not contain that period and offers to return to bulk collection.

After date checking, optional criteria may be entered. Blank fields are ignored. This means that, for example, leaving the judge field empty does not exclude any judge.

The user then enters keywords. Multiple keywords are separated by a chosen separator, usually a semicolon. If multiple keywords are supplied, the search can require either all of them or any one of them.

If no context is entered, the process ends with a keyword case list. If a brief context is entered, report generation becomes available.

## 5. Model Use and Timeout Control

The safe default profile uses `gpt-oss:20b`, `num_ctx: 8192`, low reasoning effort, and small source excerpts. This was selected because it tests the full method without the heavy loading problems encountered with larger models. The report generator processes cases one by one, with a maximum number of cases per batch. This prevents one long prompt from blocking the whole workflow.

The intended larger model remains `gpt-oss:120b`, but it is treated as an experimental profile. When the 120B model fails during loading, the failure is not caused by the legal-linguistic workflow. It usually indicates insufficient available system memory or unsuitable local runtime allocation.

## 6. Output Structure

Each keyword search produces:

| Output | Function |
|---|---|
| DOCX | human-readable list for selection and discussion |
| JSON | machine-readable list for report generation |
| CSV | spreadsheet-friendly list |

Each report contains:

1. Abstract
2. Statement of facts and linguistic problem
3. Procedural and legal context
4. Language variation or terminological issue
5. Method of interpretation
6. Outcome and significance
7. Relevance to the supplied context
8. Source note

## 7. Limits

The prototype depends on the quality of the source text. It does not use OCR. If a PDF is image-only, another source format should be used.

The collector is careful but not infallible. Public legal websites may show missing-document pages, robot checks, or dynamically loaded pages. Headed browser mode and manual checking are therefore included.

The model output is a research aid. Reports must be checked against the source document.

## 8. Integrated Conclusion

The project converts a slow manual workflow into a staged local method. The archive performs the mechanical work, the keyword list narrows the field, and the model is used only when interpretive synthesis is required. This makes legal-linguistic analysis faster, more repeatable, and easier to document without requiring the researcher to become a programmer.

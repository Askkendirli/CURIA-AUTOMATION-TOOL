# Integration of the Standalone CURIA Collector

The uploaded standalone collector was originally designed as a macOS-only source gathering tool. It used Playwright to open CURIA pages, save HTML, extract text, and create a manifest. The integrated project keeps that modular idea but moves the collector into the main Python package.

## What was retained

- Browser-based collection through Playwright.
- Saving HTML and extracted text.
- Manifest writing.
- Tolerance for missing or unpublished case pages.
- Manual handling of robot/captcha pages.

## What was changed

| Original standalone collector | Integrated version |
|---|---|
| macOS shell scripts | Windows-first PowerShell setup |
| separate downloads folder | main archive folders |
| separate manifest | archive manifest folder |
| no archive coverage record | collection runs stored in SQLite |
| no report workflow | connected to keyword lists and report generation |
| no translation workflow | connected to report translation |

The original file is retained in `legacy_mac_collector/` for reference. The integrated collector is implemented in `eu_case_ai/curia_collector.py`.

# Troubleshooting Manual

## 1. PowerShell blocks activation

Error:

```text
Activate.ps1 cannot be loaded because running scripts is disabled
```

Fix for the current PowerShell window:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## 2. Ollama cannot be reached

Error:

```text
Could not reach Ollama at http://localhost:11434
```

Fix:

```powershell
ollama serve
python -m eu_case_ai doctor
```

If `ollama` is not recognised, Ollama for Windows must be installed and PowerShell must be reopened.

## 3. Model fails to load

Error example:

```text
model requires more system memory than is available
```

The model failed before the report workflow began. Recommended steps:

```powershell
ollama ps
ollama stop gpt-oss:120b
ollama stop qwen3.5:122b
ollama stop mistral-large:123b
```

Then use the safe model profile:

```powershell
Copy-Item config.windows.safe.yaml config.yaml -Force
ollama pull gpt-oss:20b
python -m eu_case_ai model-test
```

## 4. Report generation times out

Reduce the settings in `config.yaml`:

```yaml
llm:
  num_ctx: 4096
  think: "low"
reports:
  source_chars_per_case: 8000
  max_cases_per_batch: 1
search:
  rerank_limit: 5
```

Then run report generation for one case only.

## 5. CURIA or EUR-Lex file is empty

If a downloaded HTML file has size `0`, the file contains no usable source. Browser saving or headed Playwright collection should be used.

Check the file:

```powershell
Get-Item archive\raw\en\FILE.html | Format-List FullName,Length
```

If `Length` is `0`, delete the file and collect again in headed mode:

```powershell
python -m eu_case_ai collect --years 2025 --courts C --langs en --headed --manual --max-saved 5
```

## 6. No text extracted

The prototype does not use OCR. Use HTML, text, or a PDF with embedded text.

Test extraction indirectly by ingesting one file:

```powershell
python -m eu_case_ai ingest archive\raw\en\FILE.html --lang en
```

## 7. Date range is reported unavailable

The tool checks recorded collection coverage. If no collection run covered the requested year, the date filter is treated as unavailable.

Run collection for that year:

```powershell
python -m eu_case_ai collect --years 2024 --courts C --langs en --headed --manual
```

## 8. Search returns no cases

Try:

- a broader keyword,
- `--match-mode any`,
- no date filter,
- no document-type filter,
- reingesting the source folder.

Example:

```powershell
python -m eu_case_ai search --keywords "language version; translation" --match-mode any
```

## 9. Translation is too slow

Translate one language first:

```powershell
python -m eu_case_ai translate --report reports\en\REPORT.md --targets ro
```

Reduce translation chunk size if necessary:

```yaml
translation:
  chunk_chars: 1800
```

## 10. The fastest reliable test path

```powershell
Copy-Item config.windows.safe.yaml config.yaml -Force
python -m eu_case_ai doctor
python -m eu_case_ai model-test
python -m eu_case_ai ingest archive\raw\en\62024CC0416_en.html --lang en --celex 62024CC0416
python -m eu_case_ai search --keywords "language version; legal certainty" --match-mode any
python -m eu_case_ai report --list archive\case_lists\KEYWORD_LIST.json --context "translation error recovery"
```

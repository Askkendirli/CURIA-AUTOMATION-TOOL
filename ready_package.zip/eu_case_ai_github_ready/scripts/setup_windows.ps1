Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m playwright install chromium
.\.venv\Scripts\python.exe -m eu_case_ai setup --overwrite
Write-Host "Setup complete. Activate with: .\.venv\Scripts\Activate.ps1"

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
.\.venv\Scripts\python.exe -m eu_case_ai doctor
.\.venv\Scripts\python.exe -m eu_case_ai model-test

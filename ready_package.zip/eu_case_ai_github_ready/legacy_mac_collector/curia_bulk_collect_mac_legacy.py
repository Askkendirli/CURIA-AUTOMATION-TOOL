#!/usr/bin/env python3
"""
Standalone CURIA bulk collector for macOS.

This script does not use the EU Case AI project or any local LLM. It is a lightweight
source-gathering test: it opens CURIA case search pages, follows document links, saves real
judgment/opinion/order pages as HTML + plain text, and writes a manifest CSV.

It is intentionally tolerant: missing cases and "The requested document does not exist" pages
are recorded and skipped, not treated as fatal errors.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import html
import re
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Optional
from urllib.parse import urljoin, urlencode

from bs4 import BeautifulSoup
from dateutil import parser as dateparser
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

CURIA_LIST_URL = "https://curia.europa.eu/juris/liste.jsf"

BAD_MARKERS = [
    "the requested document does not exist",
    "requested document does not exist",
    "document does not exist",
    "no documents matching criteria",
    "aucun document",
    "access denied",
    "verify you are not a robot",
    "captcha",
]

CASE_RE = re.compile(r"\b([CTF]\s*[-‑–—]\s*\d{1,4}/\d{2,4})\b", re.IGNORECASE)
ECLI_RE = re.compile(r"ECLI:EU:[A-Z]+:\d{4}:\d+", re.IGNORECASE)
DATE_PATTERNS = [
    re.compile(r"\bdelivered on\s+(\d{1,2}\s+[A-Za-z]+\s+\d{4})", re.IGNORECASE),
    re.compile(r"\bof\s+(\d{1,2}\s+[A-Za-z]+\s+\d{4})\b", re.IGNORECASE),
]
DOC_TYPES = [
    ("AG Opinion", re.compile(r"OPINION OF ADVOCATE GENERAL", re.IGNORECASE)),
    ("Judgment", re.compile(r"JUDGMENT OF THE COURT|JUDGMENT OF THE GENERAL COURT|JUDGMENT", re.IGNORECASE)),
    ("Order", re.compile(r"ORDER OF THE COURT|ORDER OF THE GENERAL COURT|ORDER", re.IGNORECASE)),
]


@dataclass
class ManifestRow:
    source_case: str
    language: str
    status: str
    source_url: str
    document_url: str = ""
    html_path: str = ""
    text_path: str = ""
    text_length: int = 0
    case_id: str = ""
    case_name: str = ""
    ecli: str = ""
    doc_type: str = ""
    delivery_date: str = ""
    reason: str = ""
    collected_at: str = ""


def normalise(text: str) -> str:
    text = html.unescape(text or "")
    text = text.replace("\x00", " ")
    text = text.replace("\u00a0", " ")
    text = text.replace("‑", "-").replace("–", "-").replace("—", "-").replace("−", "-")
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n[ \t]+", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def html_to_text(raw_html: str) -> str:
    soup = BeautifulSoup(raw_html or "", "lxml")
    for tag in soup(["script", "style", "noscript", "header", "footer", "nav"]):
        tag.decompose()
    lines: list[str] = []
    for line in soup.get_text("\n").splitlines():
        line = normalise(line)
        if not line:
            continue
        low = line.lower()
        if low in {"html", "home", "language", "document", "procedure", "close", "cookies", "legal notice"}:
            continue
        lines.append(line)
    return normalise("\n".join(lines))


def classify_text(text: str, min_chars: int) -> tuple[bool, str]:
    clean = normalise(text)
    low = clean.lower()
    for marker in BAD_MARKERS:
        if marker in low:
            return False, f"missing_or_blocked:{marker}"
    if len(clean) < min_chars:
        return False, f"too_short:{len(clean)}"
    upper = clean.upper()
    if not any(tok in upper for tok in ["OPINION OF ADVOCATE GENERAL", "JUDGMENT", "ORDER OF", "ECLI:EU", "CASE C-", "CASE T-"]):
        return False, "does_not_look_like_case_law"
    return True, "ok"


def parse_metadata(text: str, filename_hint: str = "") -> dict[str, str]:
    src = normalise(text[:25000]) + "\n" + filename_hint
    cases: list[str] = []
    for m in CASE_RE.finditer(src):
        case = m.group(1).upper().replace(" ", "")
        case = re.sub(r"[-‑–—]", "-", case)
        if case not in cases:
            cases.append(case)
    ecli_m = ECLI_RE.search(src)
    ecli = ecli_m.group(0).upper() if ecli_m else ""
    doc_type = "Document"
    for label, rx in DOC_TYPES:
        if rx.search(src):
            doc_type = label
            break
    delivery_date = ""
    for rx in DATE_PATTERNS:
        m = rx.search(src)
        if m:
            try:
                delivery_date = dateparser.parse(m.group(1), dayfirst=True).date().isoformat()
            except Exception:
                delivery_date = m.group(1)
            break
    lines = [ln.strip() for ln in src.splitlines() if ln.strip()]
    case_name = ""
    for i, ln in enumerate(lines[:220]):
        if re.search(r"\bv\b|\bversus\b", ln, re.IGNORECASE):
            case_name = " ".join(lines[max(0, i - 3): min(len(lines), i + 6)])
            case_name = re.sub(r"\s+", " ", case_name).strip()
            break
    if not case_name:
        for ln in lines[:80]:
            if len(ln) > 8 and not ln.lower().startswith(("language", "document", "procedure", "provisional text")):
                case_name = ln
                break
    return {
        "case_id": " ".join(cases),
        "case_name": case_name,
        "ecli": ecli,
        "doc_type": doc_type,
        "delivery_date": delivery_date,
    }


def case_search_url(case_ref: str, lang: str) -> str:
    # CURIA expects URL parameters, not a guessed document ID.
    params = {"language": lang.lower(), "num": case_ref}
    return f"{CURIA_LIST_URL}?{urlencode(params)}"


def case_range(court: str, start: int, end: int, year_suffix: str) -> Iterable[str]:
    court = court.upper().strip()
    year_suffix = year_suffix.strip().lstrip("/")
    if len(year_suffix) == 4:
        year_suffix = year_suffix[-2:]
    for n in range(start, end + 1):
        yield f"{court}-{n}/{year_suffix}"


def safe_name(value: str, max_len: int = 120) -> str:
    value = normalise(value)
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_")
    return (value or "document")[:max_len]


def extract_document_links(base_url: str, raw_html: str) -> list[str]:
    soup = BeautifulSoup(raw_html or "", "lxml")
    out: list[str] = []
    seen: set[str] = set()
    for a in soup.find_all("a", href=True):
        href = a.get("href") or ""
        txt = a.get_text(" ").strip().lower()
        if not href:
            continue
        full = urljoin(base_url, href)
        low = full.lower()
        # CURIA document pages commonly contain these paths. Keep the filter broad.
        if "/juris/document/" in low and ("document.jsf" in low or "document_print" in low or "docid=" in low):
            if full not in seen:
                seen.add(full)
                out.append(full)
        elif any(word in txt for word in ["judgment", "opinion", "order"]):
            if full not in seen:
                seen.add(full)
                out.append(full)
    return out


def date_ok(date_text: str, date_from: Optional[dt.date], date_to: Optional[dt.date]) -> tuple[bool, str]:
    if not date_from and not date_to:
        return True, ""
    if not date_text:
        return False, "date_missing"
    try:
        d = dateparser.parse(date_text).date()
    except Exception:
        return False, f"date_unparseable:{date_text}"
    if date_from and d < date_from:
        return False, f"before_date_from:{d}"
    if date_to and d > date_to:
        return False, f"after_date_to:{d}"
    return True, ""


def write_manifest(path: Path, rows: list[ManifestRow]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(asdict(ManifestRow(source_case="", language="", status="", source_url="")).keys())
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in rows:
            w.writerow(asdict(row))


def save_document(out_root: Path, lang: str, source_case: str, doc_url: str, raw_html: str, text: str, meta: dict[str, str], overwrite: bool) -> tuple[Path, Path]:
    date_part = meta.get("delivery_date") or "no-date"
    type_part = safe_name(meta.get("doc_type") or "document", 40)
    ecli_part = safe_name(meta.get("ecli") or "no-ecli", 60)
    case_part = safe_name(meta.get("case_id") or source_case, 40)
    base = f"{case_part}_{date_part}_{type_part}_{ecli_part}"
    html_path = out_root / "raw" / lang.lower() / f"{base}.html"
    txt_path = out_root / "text" / lang.lower() / f"{base}.txt"
    html_path.parent.mkdir(parents=True, exist_ok=True)
    txt_path.parent.mkdir(parents=True, exist_ok=True)
    if html_path.exists() and not overwrite:
        i = 2
        while True:
            hp = html_path.with_name(f"{html_path.stem}_{i}.html")
            tp = txt_path.with_name(f"{txt_path.stem}_{i}.txt")
            if not hp.exists():
                html_path, txt_path = hp, tp
                break
            i += 1
    html_path.write_text(raw_html, encoding="utf-8")
    txt_path.write_text(text, encoding="utf-8")
    return html_path, txt_path


def load_case_inputs(args) -> list[str]:
    cases: list[str] = []
    if args.case:
        cases.extend(args.case)
    if args.case_file:
        for line in Path(args.case_file).read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                cases.append(line)
    if args.case_from and args.case_to and args.case_year:
        for court in args.courts:
            cases.extend(case_range(court, args.case_from, args.case_to, args.case_year))
    # Preserve order, remove duplicates.
    seen = set()
    uniq = []
    for c in cases:
        c = c.strip().upper().replace(" ", "")
        if c and c not in seen:
            seen.add(c)
            uniq.append(c)
    return uniq


def main() -> int:
    ap = argparse.ArgumentParser(description="Standalone CURIA bulk collector for macOS")
    ap.add_argument("--case", action="append", help="Case number, e.g. C-416/24. Can be repeated.")
    ap.add_argument("--case-file", help="Text file with one case number per line.")
    ap.add_argument("--case-from", type=int, help="Start case number for generated range.")
    ap.add_argument("--case-to", type=int, help="End case number for generated range.")
    ap.add_argument("--case-year", help="Case year suffix, e.g. 24 or 2024.")
    ap.add_argument("--courts", nargs="+", default=["C"], help="Court prefixes to generate, e.g. C T.")
    ap.add_argument("--langs", nargs="+", default=["en"], help="CURIA language code(s), e.g. en fr ro.")
    ap.add_argument("--out", default="downloads", help="Output folder.")
    ap.add_argument("--headed", action="store_true", help="Show browser window.")
    ap.add_argument("--manual", action="store_true", help="Pause if robot/captcha page appears.")
    ap.add_argument("--delay", type=float, default=1.0, help="Delay between cases.")
    ap.add_argument("--wait-ms", type=int, default=1500, help="Wait after page load.")
    ap.add_argument("--min-chars", type=int, default=600, help="Minimum text length for real legal document.")
    ap.add_argument("--max-saved", type=int, default=0, help="Stop after this many saved documents; 0=no limit.")
    ap.add_argument("--overwrite", action="store_true")
    ap.add_argument("--date-from", help="Optional delivery date filter YYYY-MM-DD")
    ap.add_argument("--date-to", help="Optional delivery date filter YYYY-MM-DD")
    ap.add_argument("--manifest-name", default="")
    args = ap.parse_args()

    case_refs = load_case_inputs(args)
    if not case_refs:
        print("No cases specified. Example: python curia_bulk_collect.py --case C-416/24 --langs en --headed")
        return 2

    date_from = dt.date.fromisoformat(args.date_from) if args.date_from else None
    date_to = dt.date.fromisoformat(args.date_to) if args.date_to else None
    out_root = Path(args.out)
    manifest_root = out_root / "manifests"
    manifest_root.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    manifest_path = manifest_root / (args.manifest_name or f"curia_bulk_{stamp}.csv")

    rows: list[ManifestRow] = []
    saved = 0
    attempted = 0

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not args.headed)
        context = browser.new_context(locale="en-GB")
        page = context.new_page()
        for case_ref in case_refs:
            for lang in args.langs:
                attempted += 1
                url = case_search_url(case_ref, lang)
                row = ManifestRow(
                    source_case=case_ref,
                    language=lang.lower(),
                    status="attempted",
                    source_url=url,
                    collected_at=dt.datetime.now().isoformat(timespec="seconds"),
                )
                try:
                    page.goto(url, wait_until="domcontentloaded", timeout=60000)
                    page.wait_for_timeout(args.wait_ms)
                except PlaywrightTimeoutError:
                    pass
                raw = page.content()
                text = html_to_text(raw)
                low = text.lower()
                if args.manual and any(m in low for m in ["robot", "captcha", "verify", "javascript"]):
                    print("Manual check may be required in browser. Complete it, then press ENTER here.")
                    input()
                    page.wait_for_timeout(args.wait_ms)
                    raw = page.content()
                    text = html_to_text(raw)

                ok_current, reason_current = classify_text(text, args.min_chars)
                links = extract_document_links(page.url, raw)

                doc_pages: list[tuple[str, str, str]] = []
                if ok_current:
                    doc_pages.append((page.url, raw, text))
                for link in links:
                    try:
                        dpage = context.new_page()
                        dpage.goto(link, wait_until="domcontentloaded", timeout=60000)
                        dpage.wait_for_timeout(args.wait_ms)
                        draw = dpage.content()
                        dtext = html_to_text(draw)
                        dpage.close()
                    except Exception as exc:
                        rows.append(ManifestRow(source_case=case_ref, language=lang.lower(), status="error", source_url=url, document_url=link, reason=repr(exc), collected_at=dt.datetime.now().isoformat(timespec="seconds")))
                        continue
                    ok_doc, reason_doc = classify_text(dtext, args.min_chars)
                    if ok_doc:
                        doc_pages.append((link, draw, dtext))
                    else:
                        rows.append(ManifestRow(source_case=case_ref, language=lang.lower(), status="missing_or_blocked", source_url=url, document_url=link, text_length=len(dtext), reason=reason_doc, collected_at=dt.datetime.now().isoformat(timespec="seconds")))

                if not doc_pages:
                    row.status = "missing_or_no_document_links"
                    row.text_length = len(text)
                    row.reason = reason_current if not links else f"links_found_but_invalid:{len(links)}"
                    rows.append(row)
                    print(f"[{attempted}] {case_ref}/{lang}: {row.status} len={row.text_length} {row.reason}"[:240])
                    write_manifest(manifest_path, rows)
                    time.sleep(args.delay)
                    continue

                # Deduplicate by URL/text prefix.
                seen_docs = set()
                for doc_url, raw_html, doc_text in doc_pages:
                    fingerprint = (doc_url, doc_text[:500])
                    if fingerprint in seen_docs:
                        continue
                    seen_docs.add(fingerprint)
                    meta = parse_metadata(doc_text, filename_hint=f"{case_ref}_{lang}.html")
                    in_date, date_reason = date_ok(meta.get("delivery_date", ""), date_from, date_to)
                    if not in_date:
                        rows.append(ManifestRow(source_case=case_ref, language=lang.lower(), status="skipped", source_url=url, document_url=doc_url, text_length=len(doc_text), delivery_date=meta.get("delivery_date", ""), doc_type=meta.get("doc_type", ""), reason=date_reason, collected_at=dt.datetime.now().isoformat(timespec="seconds")))
                        continue
                    hp, tp = save_document(out_root, lang, case_ref, doc_url, raw_html, doc_text, meta, args.overwrite)
                    rows.append(ManifestRow(
                        source_case=case_ref,
                        language=lang.lower(),
                        status="saved",
                        source_url=url,
                        document_url=doc_url,
                        html_path=str(hp),
                        text_path=str(tp),
                        text_length=len(doc_text),
                        case_id=meta.get("case_id", ""),
                        case_name=meta.get("case_name", ""),
                        ecli=meta.get("ecli", ""),
                        doc_type=meta.get("doc_type", ""),
                        delivery_date=meta.get("delivery_date", ""),
                        collected_at=dt.datetime.now().isoformat(timespec="seconds"),
                    ))
                    saved += 1
                    print(f"[{attempted}] {case_ref}/{lang}: saved len={len(doc_text)} {meta.get('doc_type','')} {meta.get('delivery_date','')} {hp.name}"[:240])
                    if args.max_saved and saved >= args.max_saved:
                        write_manifest(manifest_path, rows)
                        print(f"Reached --max-saved {args.max_saved}. Manifest: {manifest_path}")
                        browser.close()
                        return 0
                write_manifest(manifest_path, rows)
                time.sleep(args.delay)
        browser.close()

    write_manifest(manifest_path, rows)
    print("\nDone.")
    print(f"Cases/languages attempted: {attempted}")
    print(f"Documents saved:           {saved}")
    print(f"Manifest:                  {manifest_path}")
    print(f"Raw output:                {out_root / 'raw'}")
    print(f"Text output:               {out_root / 'text'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# Standalone CURIA Bulk Collector for macOS

This package is separate from the AI analysis tool. It only collects public CURIA case-law pages and saves them as HTML plus plain text with a manifest CSV.

## Install

```bash
cd ~/Desktop/curia_bulk_collector_mac_standalone
chmod +x *.sh *.py
./setup_mac.sh
source .venv/bin/activate
```

## Known-case test

```bash
./run_known_curia_case_test.sh
```

This tests C-416/24 and C-417/24, the On Air / Different Media joined cases.

## Small range test

```bash
./run_small_curia_range_test.sh
```

This opens CURIA search pages for C-410/24 through C-420/24 and saves any real legal documents it finds.

Missing cases are normal. CURIA will often display "The requested document does not exist" for invalid or unpublished documents. The script records those rows in the manifest and keeps going.

## Bigger range

```bash
python curia_bulk_collect.py \
  --case-from 1 \
  --case-to 300 \
  --case-year 24 \
  --courts C \
  --langs en \
  --headed \
  --manual \
  --max-saved 50 \
  --delay 2
```

## Output

```text
downloads/raw/en/       saved HTML
downloads/text/en/      extracted text
downloads/manifests/    CSV manifest
```

Copy `downloads/raw` and `downloads/text` to the main PC later.

from __future__ import annotations

import datetime as dt
import html
import re
from pathlib import Path
from typing import Iterable, Optional


def normalise_text(text: str) -> str:
    text = html.unescape(text or "")
    text = text.replace("\x00", " ")
    text = text.replace("\u00a0", " ")
    text = text.replace("‑", "-").replace("–", "-").replace("—", "-").replace("−", "-")
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n[ \t]+", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def slugify(value: str, max_len: int = 120) -> str:
    value = normalise_text(value)
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_")
    return (value or "item")[:max_len]


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def now_stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def parse_year_range(text: str) -> tuple[int, int]:
    value = text.strip()
    m = re.match(r"^(\d{4})\s*[-–—]\s*(\d{4})$", value)
    if m:
        start, end = int(m.group(1)), int(m.group(2))
        return (min(start, end), max(start, end))
    if re.match(r"^\d{4}$", value):
        y = int(value)
        return y, y
    raise ValueError("Year range must use YYYY or YYYY-YYYY format.")


def parse_date_or_blank(value: str) -> Optional[dt.date]:
    value = (value or "").strip()
    if not value:
        return None
    return dt.date.fromisoformat(value)


def count_words(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text or "", flags=re.UNICODE))


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{prompt}{suffix}: ").strip()
    return value if value else default


def ask_choice(prompt: str, choices: Iterable[str], default: str = "") -> str:
    options = list(choices)
    label = "/".join(options)
    while True:
        value = ask(f"{prompt} ({label})", default).strip().lower()
        if value in options:
            return value
        print(f"Invalid choice. Accepted values: {', '.join(options)}")


def split_keywords(raw: str, sep: str = ";") -> list[str]:
    if not sep:
        sep = ";"
    parts = [p.strip() for p in raw.split(sep)]
    return [p for p in parts if p]


def context_10_words(raw: str) -> str:
    words = re.findall(r"\S+", raw or "")
    return " ".join(words[:10])

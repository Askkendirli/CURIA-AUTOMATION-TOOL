from __future__ import annotations

import csv
import datetime as dt
import json
import re
import shutil
import sqlite3
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from .config import prepare_directories
from .extractor import extract_text, parse_metadata
from .utils import normalise_text, slugify, now_stamp


def chunk_text(text: str, max_chars: int, overlap: int) -> list[str]:
    text = normalise_text(text)
    if not text:
        return []
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = min(len(text), start + max_chars)
        cut = text.rfind("\n\n", start, end)
        if cut <= start + max_chars // 2:
            cut = end
        chunks.append(text[start:cut].strip())
        if cut >= len(text):
            break
        start = max(0, cut - overlap)
    return [c for c in chunks if c]


class CaseArchive:
    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg
        prepare_directories(cfg)
        self.db_path = Path(cfg["archive"]["database"])

    def connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path)
        con.row_factory = sqlite3.Row
        return con

    def init_db(self) -> None:
        with self.connect() as con:
            con.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS documents (
                    doc_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE NOT NULL,
                    text_path TEXT,
                    source_url TEXT,
                    language TEXT,
                    case_key TEXT,
                    case_id TEXT,
                    case_name TEXT,
                    case_numbers TEXT,
                    ecli TEXT,
                    celex TEXT,
                    doc_type TEXT,
                    delivery_date TEXT,
                    judge TEXT,
                    advocate_general TEXT,
                    text_length INTEGER,
                    added_at TEXT
                );
                CREATE TABLE IF NOT EXISTS chunks (
                    chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    doc_id INTEGER NOT NULL,
                    case_key TEXT,
                    chunk_no INTEGER,
                    text TEXT NOT NULL,
                    FOREIGN KEY(doc_id) REFERENCES documents(doc_id) ON DELETE CASCADE
                );
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
                    text,
                    case_key UNINDEXED,
                    doc_id UNINDEXED,
                    chunk_no UNINDEXED,
                    tokenize='unicode61 remove_diacritics 2'
                );
                CREATE TABLE IF NOT EXISTS collection_runs (
                    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    start_year INTEGER,
                    end_year INTEGER,
                    courts TEXT,
                    languages TEXT,
                    status TEXT,
                    manifest_path TEXT,
                    created_at TEXT
                );
                CREATE TABLE IF NOT EXISTS keyword_lists (
                    list_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    list_name TEXT,
                    path_json TEXT,
                    path_docx TEXT,
                    keywords TEXT,
                    match_mode TEXT,
                    context TEXT,
                    created_at TEXT
                );
                """
            )

    def record_collection_run(self, start_year: int, end_year: int, courts: Iterable[str], languages: Iterable[str], status: str, manifest_path: str) -> None:
        with self.connect() as con:
            con.execute(
                "INSERT INTO collection_runs (start_year,end_year,courts,languages,status,manifest_path,created_at) VALUES (?,?,?,?,?,?,?)",
                (start_year, end_year, ",".join(courts), ",".join(languages), status, manifest_path, dt.datetime.now().isoformat(timespec="seconds")),
            )

    def has_year_coverage(self, start_date: Optional[str], end_date: Optional[str]) -> bool:
        if not start_date and not end_date:
            return True
        years: list[int] = []
        for value in [start_date, end_date]:
            if value:
                try:
                    years.append(dt.date.fromisoformat(value).year)
                except Exception:
                    pass
        if not years:
            return True
        start_year, end_year = min(years), max(years)
        with self.connect() as con:
            row = con.execute(
                "SELECT COUNT(*) AS n FROM collection_runs WHERE start_year <= ? AND end_year >= ? AND status IN ('completed','partial')",
                (start_year, end_year),
            ).fetchone()
        return bool(row and row["n"] > 0)

    def ingest_path(self, path: str | Path, *, lang: str = "en", celex: str = "", source_url: str = "") -> list[int]:
        p = Path(path)
        files: list[Path]
        if p.is_dir():
            files = [x for x in p.rglob("*") if x.suffix.lower() in {".html", ".htm", ".txt", ".pdf", ".xml", ".xhtml", ".md"}]
        else:
            files = [p]
        ids: list[int] = []
        for item in files:
            ids.append(self.ingest_file(item, lang=lang, celex=celex, source_url=source_url))
        return ids

    def ingest_file(self, path: str | Path, *, lang: str = "en", celex: str = "", source_url: str = "") -> int:
        p = Path(path)
        text = extract_text(p)
        if not text.strip():
            raise ValueError(f"No embedded text extracted from {p}. OCR is not used by this prototype.")
        meta = parse_metadata(text, filename=p.name, celex_hint=celex, lang=lang, source_url=source_url)
        case_key = slugify(meta.get("case_id") or meta.get("case_name") or p.stem, 100).lower()
        text_dir = Path(self.cfg["archive"]["text_dir"]) / (lang or meta.get("language") or "unknown")
        text_dir.mkdir(parents=True, exist_ok=True)
        text_path = text_dir / f"{slugify(p.stem, 100)}.txt"
        text_path.write_text(text, encoding="utf-8")
        chunks = chunk_text(text, int(self.cfg["chunking"]["max_chars"]), int(self.cfg["chunking"]["overlap_chars"]))
        with self.connect() as con:
            existing = con.execute("SELECT doc_id FROM documents WHERE path=?", (str(p),)).fetchone()
            if existing:
                doc_id = int(existing["doc_id"])
                con.execute("DELETE FROM chunks WHERE doc_id=?", (doc_id,))
                con.execute("DELETE FROM chunks_fts WHERE doc_id=?", (doc_id,))
                con.execute(
                    """
                    UPDATE documents SET text_path=?, source_url=?, language=?, case_key=?, case_id=?, case_name=?,
                    case_numbers=?, ecli=?, celex=?, doc_type=?, delivery_date=?, judge=?, advocate_general=?, text_length=?
                    WHERE doc_id=?
                    """,
                    (str(text_path), source_url or meta.get("source_url", ""), lang or meta.get("language", ""), case_key,
                     meta.get("case_id", ""), meta.get("case_name", ""), meta.get("case_numbers", ""), meta.get("ecli", ""),
                     meta.get("celex", ""), meta.get("doc_type", "Document"), meta.get("delivery_date", ""), meta.get("judge", ""),
                     meta.get("advocate_general", ""), len(text), doc_id),
                )
            else:
                cur = con.execute(
                    """
                    INSERT INTO documents (path,text_path,source_url,language,case_key,case_id,case_name,case_numbers,ecli,celex,doc_type,delivery_date,judge,advocate_general,text_length,added_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """,
                    (str(p), str(text_path), source_url or meta.get("source_url", ""), lang or meta.get("language", ""), case_key,
                     meta.get("case_id", ""), meta.get("case_name", ""), meta.get("case_numbers", ""), meta.get("ecli", ""),
                     meta.get("celex", ""), meta.get("doc_type", "Document"), meta.get("delivery_date", ""), meta.get("judge", ""),
                     meta.get("advocate_general", ""), len(text), dt.datetime.now().isoformat(timespec="seconds")),
                )
                doc_id = int(cur.lastrowid)
            for i, chunk in enumerate(chunks):
                cur = con.execute("INSERT INTO chunks (doc_id,case_key,chunk_no,text) VALUES (?,?,?,?)", (doc_id, case_key, i, chunk))
                con.execute("INSERT INTO chunks_fts(rowid,text,case_key,doc_id,chunk_no) VALUES (?,?,?,?,?)", (int(cur.lastrowid), chunk, case_key, doc_id, i))
        return doc_id

    def status(self) -> Dict[str, int]:
        with self.connect() as con:
            docs = con.execute("SELECT COUNT(*) AS n FROM documents").fetchone()["n"]
            cases = con.execute("SELECT COUNT(DISTINCT case_key) AS n FROM documents").fetchone()["n"]
            chunks = con.execute("SELECT COUNT(*) AS n FROM chunks").fetchone()["n"]
            lists = con.execute("SELECT COUNT(*) AS n FROM keyword_lists").fetchone()["n"]
        return {"documents": int(docs), "cases": int(cases), "chunks": int(chunks), "keyword_lists": int(lists)}

    def fts_query(self, keywords: list[str], match_mode: str) -> str:
        terms = []
        for kw in keywords:
            kw = kw.strip().replace('"', ' ')
            if not kw:
                continue
            parts = [p for p in re.findall(r"[\w-]{3,}", kw, flags=re.UNICODE)]
            if len(parts) > 1:
                terms.append('"' + " ".join(parts) + '"')
            elif parts:
                terms.append(f'"{parts[0]}"*')
        joiner = " AND " if match_mode == "all" else " OR "
        return joiner.join(terms) if terms else ""

    def search_cases(self, keywords: list[str], match_mode: str = "any", filters: Optional[Dict[str, str]] = None, limit: Optional[int] = None) -> list[Dict[str, Any]]:
        filters = filters or {}
        fts = self.fts_query(keywords, match_mode)
        if not fts:
            return []
        limit = limit or int(self.cfg["search"]["fts_limit"])
        where = ["chunks_fts MATCH ?"]
        params: list[Any] = [fts]
        if filters.get("date_from"):
            where.append("d.delivery_date >= ?")
            params.append(filters["date_from"])
        if filters.get("date_to"):
            where.append("d.delivery_date <= ?")
            params.append(filters["date_to"])
        for key in ["doc_type", "judge", "advocate_general", "language", "ecli", "celex", "case_id", "case_name"]:
            value = (filters.get(key) or "").strip()
            if value:
                where.append(f"LOWER(d.{key}) LIKE ?")
                params.append(f"%{value.lower()}%")
        params.append(limit)
        sql = f"""
            SELECT c.chunk_id,c.case_key,c.chunk_no,c.text,d.*,
                   bm25(chunks_fts) AS score
            FROM chunks_fts
            JOIN chunks c ON c.chunk_id=chunks_fts.rowid
            JOIN documents d ON d.doc_id=c.doc_id
            WHERE {' AND '.join(where)}
            ORDER BY score ASC
            LIMIT ?
        """
        with self.connect() as con:
            rows = con.execute(sql, params).fetchall()
        groups: Dict[str, Dict[str, Any]] = {}
        for row in rows:
            key = row["case_key"]
            g = groups.setdefault(key, {
                "case_key": key,
                "case_id": row["case_id"],
                "case_name": row["case_name"],
                "doc_type": row["doc_type"],
                "delivery_date": row["delivery_date"],
                "ecli": row["ecli"],
                "celex": row["celex"],
                "language": row["language"],
                "path": row["path"],
                "score": float(row["score"]),
                "matches": [],
            })
            g["score"] = min(g["score"], float(row["score"]))
            g["matches"].append({"chunk_no": row["chunk_no"], "text": row["text"][:600], "path": row["path"]})
        return sorted(groups.values(), key=lambda x: x["score"])

    def get_case_chunks(self, case_key: str, max_chars: int) -> str:
        with self.connect() as con:
            rows = con.execute(
                "SELECT d.case_id,d.case_name,d.doc_type,d.delivery_date,d.ecli,d.celex,d.path,c.chunk_no,c.text FROM chunks c JOIN documents d ON d.doc_id=c.doc_id WHERE c.case_key=? ORDER BY d.delivery_date,c.chunk_no",
                (case_key,),
            ).fetchall()
        header = ""
        body = ""
        for row in rows:
            marker = f"\n--- {row['case_id']} | {row['doc_type']} | {row['delivery_date']} | {row['ecli']} | chunk {row['chunk_no']} | {row['path']} ---\n"
            piece = marker + row["text"] + "\n"
            if len(header) + len(body) + len(piece) > max_chars:
                break
            body += piece
        return body.strip()

    def register_keyword_list(self, name: str, path_json: str, path_docx: str, keywords: list[str], match_mode: str, context: str) -> None:
        with self.connect() as con:
            con.execute(
                "INSERT INTO keyword_lists (list_name,path_json,path_docx,keywords,match_mode,context,created_at) VALUES (?,?,?,?,?,?,?)",
                (name, path_json, path_docx, "; ".join(keywords), match_mode, context, dt.datetime.now().isoformat(timespec="seconds")),
            )

    def recent_keyword_lists(self, limit: int = 10) -> list[sqlite3.Row]:
        with self.connect() as con:
            return con.execute("SELECT * FROM keyword_lists ORDER BY list_id DESC LIMIT ?", (limit,)).fetchall()

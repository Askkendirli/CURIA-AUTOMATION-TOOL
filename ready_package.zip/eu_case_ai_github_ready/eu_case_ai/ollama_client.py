from __future__ import annotations

import json
from typing import Any, Dict, List

import requests


class OllamaError(RuntimeError):
    pass


class OllamaClient:
    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg
        self.url = cfg["llm"].get("ollama_url", "http://localhost:11434").rstrip("/")
        self.timeout = int(cfg["llm"].get("timeout_seconds", 900))

    def tags(self) -> Dict[str, Any]:
        try:
            r = requests.get(f"{self.url}/api/tags", timeout=20)
            r.raise_for_status()
            return r.json()
        except Exception as exc:
            raise OllamaError(f"Ollama could not be reached at {self.url}: {exc}") from exc

    def chat(self, model: str, messages: List[Dict[str, str]], *, json_mode: bool = False, temperature: float | None = None) -> str:
        llm = self.cfg["llm"]
        options = {
            "temperature": llm.get("temperature", 0.1) if temperature is None else temperature,
            "num_ctx": int(llm.get("num_ctx", 8192)),
        }
        payload: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": options,
            "keep_alive": llm.get("keep_alive", "0"),
        }
        think = llm.get("think", "low")
        if think not in (None, "", "false", False):
            payload["think"] = think
        if json_mode:
            payload["format"] = "json"
        r = requests.post(f"{self.url}/api/chat", json=payload, timeout=self.timeout)
        if r.status_code != 200:
            raise OllamaError(f"Ollama returned HTTP {r.status_code}: {r.text[:1000]}")
        data = r.json()
        return data.get("message", {}).get("content", "")

    def chat_json(self, model: str, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        content = self.chat(model, messages, json_mode=True)
        try:
            return json.loads(content)
        except Exception:
            start = content.find("{")
            end = content.rfind("}")
            if start >= 0 and end > start:
                return json.loads(content[start:end + 1])
            raise OllamaError("The model did not return valid JSON.")

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from .archive import CaseArchive
from .constants import EU_OFFICIAL_LANGUAGES
from .curia_collector import CuriaCollector
from .list_writer import load_keyword_list, write_keyword_list
from .reporter import ReportGenerator
from .translator import ReportTranslator
from .utils import ask, ask_choice, context_10_words, parse_year_range, split_keywords


def collect_years_interactive(cfg: Dict[str, Any], archive: CaseArchive) -> None:
    value = ask("Enter year range for local CURIA collection, for example 2024-2025", "2025")
    start, end = parse_year_range(value)
    courts_raw = ask("Court prefixes separated by comma", ",".join(cfg["curia"].get("default_courts", ["C"])))
    langs_raw = ask("Languages separated by comma", ",".join(cfg["curia"].get("default_languages", ["en"])))
    max_case = int(ask("Maximum case number per year/court", str(cfg["curia"].get("max_case_number", 900))))
    max_saved = int(ask("Stop after this many saved documents; 0 means no stop", "0"))
    collector = CuriaCollector(cfg, archive)
    manifest = collector.collect_years(
        start,
        end,
        courts=[x.strip().upper() for x in courts_raw.split(",") if x.strip()],
        langs=[x.strip().lower() for x in langs_raw.split(",") if x.strip()],
        max_case_number=max_case,
        ingest=True,
        max_saved=max_saved,
    )
    print(f"Collection manifest written to: {manifest}")


def ask_filters(archive: CaseArchive) -> Dict[str, str]:
    print("Date is checked first. If the date range has not been collected locally, the collection step is offered.")
    date_from = ask("Date from YYYY-MM-DD; blank for no lower limit", "")
    date_to = ask("Date to YYYY-MM-DD; blank for no upper limit", "")
    if not archive.has_year_coverage(date_from or None, date_to or None):
        print("The entered date is not available in the local collection coverage records.")
        choice = ask_choice("Return to bulk collection now", ["y", "n"], "y")
        if choice == "y":
            collect_years_interactive(archive.cfg, archive)
    return {
        "date_from": date_from,
        "date_to": date_to,
        "doc_type": ask("Document type, e.g. AG Opinion/Judgment/Order; blank for all", ""),
        "judge": ask("Judge-Rapporteur; blank for all", ""),
        "advocate_general": ask("Advocate General; blank for all", ""),
        "language": ask("Language code; blank for all", ""),
        "case_id": ask("Case number; blank for all", ""),
        "case_name": ask("Party/name search; blank for all", ""),
        "ecli": ask("ECLI; blank for all", ""),
        "celex": ask("CELEX; blank for all", ""),
    }


def search_keyword_list_interactive(cfg: Dict[str, Any], archive: CaseArchive) -> Dict[str, Any]:
    filters = ask_filters(archive)
    raw = ask("Enter keyword(s). Use semicolon as separator for multiple entries", "language version; legal certainty")
    sep = ask("Separator", ";")
    keywords = split_keywords(raw, sep)
    match_mode = "any"
    if len(keywords) > 1:
        match_mode = ask_choice("Should all keywords be present, or any one keyword", ["all", "any"], "any")
    context = context_10_words(ask("Optional context, 10 words maximum. Blank means no report generation", ""))
    cases = archive.search_cases(keywords, match_mode=match_mode, filters=filters)
    paths = write_keyword_list(cfg["archive"]["list_dir"], keywords, match_mode, filters, context, cases)
    archive.register_keyword_list(paths["name"], paths["json"], paths["docx"], keywords, match_mode, context)
    print(f"Human-readable list: {paths['docx']}")
    print(f"Machine-readable list: {paths['json']}")
    print(f"Cases found: {len(cases)}")
    return {"paths": paths, "keywords": keywords, "match_mode": match_mode, "context": context, "cases": cases}


def choose_recent_list(archive: CaseArchive) -> Dict[str, Any]:
    rows = archive.recent_keyword_lists(10)
    if not rows:
        print("No recent keyword lists exist. A new criteria workflow will be started.")
        return search_keyword_list_interactive(archive.cfg, archive)
    for i, row in enumerate(rows, start=1):
        print(f"{i}. {row['list_name']} | {row['keywords']} | {row['created_at']}")
    choice = int(ask("Choose list number", "1"))
    row = rows[choice - 1]
    data = load_keyword_list(row["path_json"])
    return {"paths": {"json": row["path_json"], "docx": row["path_docx"]}, "keywords": data.get("keywords", []), "match_mode": data.get("match_mode", "any"), "context": data.get("context", ""), "cases": data.get("cases", [])}


def import_specific_list() -> Dict[str, Any]:
    path = ask("Enter full path to imported JSON or CSV keyword case list", "")
    data = load_keyword_list(path)
    context = context_10_words(ask("Optional context, 10 words maximum", data.get("context", "")))
    data["context"] = context
    return {"paths": {"json": path}, "keywords": data.get("keywords", []), "match_mode": data.get("match_mode", "any"), "context": context, "cases": data.get("cases", [])}


def choose_cases_for_report(archive: CaseArchive, payload: Dict[str, Any]) -> list[Dict[str, Any]]:
    cases = payload.get("cases", [])
    if not cases:
        print("The list contains no cases.")
        return []
    choice = ask_choice("Generate reports for all listed cases or selected cases", ["all", "select"], "select")
    if choice == "all":
        return cases
    select_mode = ask_choice("Select from list or search again", ["list", "search"], "list")
    if select_mode == "search":
        fresh = search_keyword_list_interactive(archive.cfg, archive)
        if not fresh.get("cases"):
            print("No cases were returned. Selection returns to the existing list.")
        else:
            cases = fresh["cases"]
    for i, case in enumerate(cases, start=1):
        print(f"{i}. {case.get('case_id','')} | {case.get('delivery_date','')} | {case.get('doc_type','')} | {case.get('case_name','')[:100]}")
    raw = ask("Enter case numbers from this list, separated by comma", "1")
    indices = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            index = int(part)
            if 1 <= index <= len(cases):
                indices.append(index - 1)
    return [cases[i] for i in indices]


def maybe_translate(cfg: Dict[str, Any], report_paths: list[str]) -> None:
    if not report_paths:
        return
    choice = ask_choice("Translate the completed report(s) into EU language(s)", ["y", "n"], "n")
    if choice != "y":
        return
    print("EU language codes:", ", ".join(EU_OFFICIAL_LANGUAGES.keys()))
    raw = ask("Target language code(s), comma-separated, or 'all'", "ro")
    if raw.strip().lower() == "all":
        targets = [code for code in EU_OFFICIAL_LANGUAGES if code != "en"]
    else:
        targets = [x.strip().lower() for x in raw.split(",") if x.strip()]
    translator = ReportTranslator(cfg)
    for report in report_paths:
        out = translator.translate_report(report, targets)
        for path in out:
            print(f"Translated: {path}")


def run_interactive(cfg: Dict[str, Any]) -> None:
    archive = CaseArchive(cfg)
    archive.init_db()
    print("Legal-Linguistic EU Case-Law Tool")
    print("1. Work by specifying local criteria and keywords")
    print("2. Work from a recently generated keyword case list")
    print("3. Work from a specific imported keyword case list")
    print("4. Bulk collect CURIA documents for a year range")
    mode = ask_choice("Choose mode", ["1", "2", "3", "4"], "1")
    if mode == "4":
        collect_years_interactive(cfg, archive)
        return
    if mode == "1":
        payload = search_keyword_list_interactive(cfg, archive)
    elif mode == "2":
        payload = choose_recent_list(archive)
        payload["context"] = context_10_words(ask("Brief context, 10 words maximum", payload.get("context", "")))
    else:
        payload = import_specific_list()
    if not payload.get("context"):
        print("No context was supplied. The workflow stops after producing the keyword list.")
        return
    selected = choose_cases_for_report(archive, payload)
    if not selected:
        print("No cases selected for report generation.")
        return
    generator = ReportGenerator(cfg, archive)
    paths = generator.generate_for_cases(selected, payload.get("keywords", []), payload.get("context", ""))
    for path in paths:
        print(f"Report written: {path}")
    maybe_translate(cfg, paths)
    print("Done.")

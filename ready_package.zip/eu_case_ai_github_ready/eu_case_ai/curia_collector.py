from __future__ import annotations

import argparse
import csv
import datetime as dt
import re
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional
from urllib.parse import urlencode, urljoin

from bs4 import BeautifulSoup
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright

from .archive import CaseArchive
from .extractor import html_to_text, parse_metadata
from .utils import normalise_text, now_stamp, slugify

BAD_MARKERS = [
    "the requested document does not exist",
    "requested document does not exist",
    "document does not exist",
    "no documents matching criteria",
    "access denied",
    "verify you are not a robot",
    "captcha",
]


@dataclass
class ManifestRow:
    source_case: str
    language: str
    status: str
    source_url: str
    document_url: str = ""
    html_path: str = ""
    text_path: str = ""
    text_length: int = 0
    case_id: str = ""
    case_name: str = ""
    ecli: str = ""
    celex: str = ""
    doc_type: str = ""
    delivery_date: str = ""
    judge: str = ""
    advocate_general: str = ""
    reason: str = ""
    collected_at: str = ""


def case_search_url(base: str, case_ref: str, lang: str) -> str:
    params = {"language": lang.lower(), "num": case_ref}
    return f"{base}?{urlencode(params)}"


def case_range(court: str, year: int, max_case: int) -> Iterable[str]:
    suffix = str(year)[-2:]
    court = court.upper().strip()
    for n in range(1, max_case + 1):
        yield f"{court}-{n}/{suffix}"


def classify_text(text: str, min_chars: int) -> tuple[bool, str]:
    clean = normalise_text(text)
    low = clean.lower()
    for marker in BAD_MARKERS:
        if marker in low:
            return False, f"missing_or_blocked:{marker}"
    if len(clean) < min_chars:
        return False, f"too_short:{len(clean)}"
    upper = clean.upper()
    if not any(tok in upper for tok in ["OPINION OF ADVOCATE GENERAL", "JUDGMENT", "ORDER OF", "ECLI:EU", "CASE C-", "CASE T-"]):
        return False, "does_not_look_like_case_law"
    return True, "ok"


def extract_document_links(base_url: str, raw_html: str) -> list[str]:
    soup = BeautifulSoup(raw_html or "", "lxml")
    out: list[str] = []
    seen: set[str] = set()
    for a in soup.find_all("a", href=True):
        href = a.get("href") or ""
        label = a.get_text(" ").strip().lower()
        full = urljoin(base_url, href)
        low = full.lower()
        if "/juris/document/" in low and ("document.jsf" in low or "document_print" in low or "docid=" in low):
            if full not in seen:
                seen.add(full)
                out.append(full)
        elif any(word in label for word in ["judgment", "opinion", "order"]):
            if full not in seen:
                seen.add(full)
                out.append(full)
    return out


def write_manifest(path: Path, rows: list[ManifestRow]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(asdict(ManifestRow(source_case="", language="", status="", source_url="")).keys())
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for row in rows:
            w.writerow(asdict(row))


def save_document(cfg: Dict[str, Any], lang: str, source_case: str, doc_url: str, raw_html: str, text: str, meta: Dict[str, str], overwrite: bool) -> tuple[Path, Path]:
    raw_root = Path(cfg["archive"]["raw_dir"]) / lang.lower()
    text_root = Path(cfg["archive"]["text_dir"]) / lang.lower()
    raw_root.mkdir(parents=True, exist_ok=True)
    text_root.mkdir(parents=True, exist_ok=True)
    date_part = meta.get("delivery_date") or "no-date"
    case_part = slugify(meta.get("case_id") or source_case, 50)
    type_part = slugify(meta.get("doc_type") or "document", 40)
    ecli_part = slugify(meta.get("ecli") or meta.get("celex") or "no-id", 60)
    base = f"{case_part}_{date_part}_{type_part}_{ecli_part}"
    html_path = raw_root / f"{base}.html"
    txt_path = text_root / f"{base}.txt"
    if html_path.exists() and not overwrite:
        index = 2
        while True:
            candidate_html = html_path.with_name(f"{html_path.stem}_{index}.html")
            candidate_txt = txt_path.with_name(f"{txt_path.stem}_{index}.txt")
            if not candidate_html.exists():
                html_path, txt_path = candidate_html, candidate_txt
                break
            index += 1
    html_path.write_text(raw_html, encoding="utf-8")
    txt_path.write_text(text, encoding="utf-8")
    return html_path, txt_path


class CuriaCollector:
    def __init__(self, cfg: Dict[str, Any], archive: Optional[CaseArchive] = None):
        self.cfg = cfg
        self.archive = archive

    def collect_years(
        self,
        start_year: int,
        end_year: int,
        *,
        courts: Optional[list[str]] = None,
        langs: Optional[list[str]] = None,
        max_case_number: Optional[int] = None,
        headed: Optional[bool] = None,
        manual: Optional[bool] = None,
        ingest: bool = True,
        max_saved: int = 0,
        overwrite: bool = False,
    ) -> str:
        curia_cfg = self.cfg["curia"]
        courts = courts or curia_cfg.get("default_courts", ["C"])
        langs = langs or curia_cfg.get("default_languages", ["en"])
        max_case_number = max_case_number or int(curia_cfg.get("max_case_number", 900))
        headed = bool(curia_cfg.get("headed", True) if headed is None else headed)
        manual = bool(curia_cfg.get("manual_check", True) if manual is None else manual)
        delay = float(curia_cfg.get("delay_seconds", 1.0))
        wait_ms = int(curia_cfg.get("wait_ms", 1500))
        min_chars = int(curia_cfg.get("min_chars", 600))
        base_url = curia_cfg.get("base_list_url", "https://curia.europa.eu/juris/liste.jsf")
        manifest_path = Path(self.cfg["archive"]["manifest_dir"]) / f"curia_collection_{start_year}_{end_year}_{now_stamp()}.csv"
        rows: list[ManifestRow] = []
        saved = 0
        status = "partial"
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=not headed)
                context = browser.new_context(locale="en-GB")
                page = context.new_page()
                for year in range(start_year, end_year + 1):
                    for court in courts:
                        for case_ref in case_range(court, year, max_case_number):
                            for lang in langs:
                                url = case_search_url(base_url, case_ref, lang)
                                row = ManifestRow(case_ref, lang.lower(), "attempted", url, collected_at=dt.datetime.now().isoformat(timespec="seconds"))
                                try:
                                    page.goto(url, wait_until="domcontentloaded", timeout=60000)
                                    page.wait_for_timeout(wait_ms)
                                except PlaywrightTimeoutError:
                                    pass
                                raw = page.content()
                                text = html_to_text(raw)
                                low = text.lower()
                                if manual and any(m in low for m in ["robot", "captcha", "verify", "javascript"]):
                                    print("Manual browser check may be required. Complete the page challenge, then press ENTER.")
                                    input()
                                    page.wait_for_timeout(wait_ms)
                                    raw = page.content()
                                    text = html_to_text(raw)
                                ok_current, reason_current = classify_text(text, min_chars)
                                doc_pages: list[tuple[str, str, str]] = []
                                if ok_current:
                                    doc_pages.append((page.url, raw, text))
                                links = extract_document_links(page.url, raw)
                                for link in links:
                                    try:
                                        dpage = context.new_page()
                                        dpage.goto(link, wait_until="domcontentloaded", timeout=60000)
                                        dpage.wait_for_timeout(wait_ms)
                                        draw = dpage.content()
                                        dtext = html_to_text(draw)
                                        dpage.close()
                                    except Exception as exc:
                                        rows.append(ManifestRow(case_ref, lang.lower(), "error", url, document_url=link, reason=repr(exc), collected_at=dt.datetime.now().isoformat(timespec="seconds")))
                                        continue
                                    ok_doc, reason_doc = classify_text(dtext, min_chars)
                                    if ok_doc:
                                        doc_pages.append((link, draw, dtext))
                                    else:
                                        rows.append(ManifestRow(case_ref, lang.lower(), "missing_or_blocked", url, document_url=link, text_length=len(dtext), reason=reason_doc, collected_at=dt.datetime.now().isoformat(timespec="seconds")))
                                if not doc_pages:
                                    row.status = "missing_or_no_document_links"
                                    row.text_length = len(text)
                                    row.reason = reason_current if not links else f"links_found_but_invalid:{len(links)}"
                                    rows.append(row)
                                    write_manifest(manifest_path, rows)
                                    time.sleep(delay)
                                    continue
                                seen: set[tuple[str, str]] = set()
                                for doc_url, raw_html, doc_text in doc_pages:
                                    fp = (doc_url, doc_text[:500])
                                    if fp in seen:
                                        continue
                                    seen.add(fp)
                                    meta = parse_metadata(doc_text, filename=f"{case_ref}_{lang}.html", lang=lang, source_url=doc_url)
                                    hp, tp = save_document(self.cfg, lang, case_ref, doc_url, raw_html, doc_text, meta, overwrite)
                                    if ingest and self.archive is not None:
                                        self.archive.ingest_file(hp, lang=lang, celex=meta.get("celex", ""), source_url=doc_url)
                                    rows.append(ManifestRow(
                                        source_case=case_ref,
                                        language=lang.lower(),
                                        status="saved",
                                        source_url=url,
                                        document_url=doc_url,
                                        html_path=str(hp),
                                        text_path=str(tp),
                                        text_length=len(doc_text),
                                        case_id=meta.get("case_id", ""),
                                        case_name=meta.get("case_name", ""),
                                        ecli=meta.get("ecli", ""),
                                        celex=meta.get("celex", ""),
                                        doc_type=meta.get("doc_type", ""),
                                        delivery_date=meta.get("delivery_date", ""),
                                        judge=meta.get("judge", ""),
                                        advocate_general=meta.get("advocate_general", ""),
                                        collected_at=dt.datetime.now().isoformat(timespec="seconds"),
                                    ))
                                    saved += 1
                                    print(f"saved {case_ref}/{lang}: {meta.get('doc_type','')} {meta.get('delivery_date','')} {hp.name}"[:220])
                                    write_manifest(manifest_path, rows)
                                    if max_saved and saved >= max_saved:
                                        browser.close()
                                        status = "partial"
                                        if self.archive is not None:
                                            self.archive.record_collection_run(start_year, end_year, courts, langs, status, str(manifest_path))
                                        return str(manifest_path)
                                time.sleep(delay)
                browser.close()
            status = "completed"
        finally:
            write_manifest(manifest_path, rows)
            if self.archive is not None:
                self.archive.record_collection_run(start_year, end_year, courts or [], langs or [], status, str(manifest_path))
        return str(manifest_path)

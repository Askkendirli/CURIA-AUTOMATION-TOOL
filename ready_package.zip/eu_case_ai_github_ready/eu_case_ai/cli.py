from __future__ import annotations

import argparse
import shutil
from pathlib import Path
from typing import Sequence

from .archive import CaseArchive
from .config import DEFAULT_CONFIG, SAFE_CONFIG, load_config, prepare_directories
from .constants import EU_OFFICIAL_LANGUAGES
from .curia_collector import CuriaCollector
from .list_writer import load_keyword_list, write_keyword_list
from .reporter import ReportGenerator
from .translator import ReportTranslator
from .troubleshoot import doctor, quick_model_test
from .utils import parse_year_range, split_keywords
from .workflow import run_interactive


def cmd_setup(args: argparse.Namespace) -> None:
    target = Path(DEFAULT_CONFIG)
    if target.exists() and not args.overwrite:
        print("config.yaml already exists. Use --overwrite to replace it with the safe Windows profile.")
    else:
        shutil.copyfile(SAFE_CONFIG, target)
        print("Created config.yaml from config.windows.safe.yaml")
    cfg = load_config(target)
    prepare_directories(cfg)
    CaseArchive(cfg).init_db()
    print("Archive directories and database are ready.")


def cmd_init(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    prepare_directories(cfg)
    CaseArchive(cfg).init_db()
    print("Archive initialized.")


def cmd_doctor(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    print(doctor(cfg))


def cmd_model_test(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    print(quick_model_test(cfg))


def cmd_ingest(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    archive = CaseArchive(cfg)
    archive.init_db()
    ids = archive.ingest_path(args.path, lang=args.lang, celex=args.celex or "", source_url=args.source_url or "")
    print(f"Ingested {len(ids)} document(s). IDs: {ids}")


def cmd_collect(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    archive = CaseArchive(cfg)
    archive.init_db()
    if args.years:
        start, end = parse_year_range(args.years)
    else:
        start, end = args.start_year, args.end_year
    courts = [x.strip().upper() for x in args.courts.split(",") if x.strip()]
    langs = [x.strip().lower() for x in args.langs.split(",") if x.strip()]
    manifest = CuriaCollector(cfg, archive).collect_years(
        start,
        end,
        courts=courts,
        langs=langs,
        max_case_number=args.max_case_number,
        headed=args.headed,
        manual=args.manual,
        ingest=not args.no_ingest,
        max_saved=args.max_saved,
        overwrite=args.overwrite,
    )
    print(f"Collection manifest: {manifest}")


def cmd_search(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    archive = CaseArchive(cfg)
    archive.init_db()
    keywords = split_keywords(args.keywords, args.separator)
    filters = {
        "date_from": args.date_from or "",
        "date_to": args.date_to or "",
        "doc_type": args.doc_type or "",
        "judge": args.judge or "",
        "advocate_general": args.advocate_general or "",
        "language": args.lang or "",
        "case_id": args.case_id or "",
        "case_name": args.case_name or "",
        "ecli": args.ecli or "",
        "celex": args.celex or "",
    }
    if not archive.has_year_coverage(filters["date_from"] or None, filters["date_to"] or None):
        print("The entered date range is not available in the recorded local collection coverage.")
        print("Run a collection first, for example: python -m eu_case_ai collect --years 2024-2025 --courts C --langs en --ingest")
        return
    cases = archive.search_cases(keywords, match_mode=args.match_mode, filters=filters)
    paths = write_keyword_list(cfg["archive"]["list_dir"], keywords, args.match_mode, filters, args.context or "", cases)
    archive.register_keyword_list(paths["name"], paths["json"], paths["docx"], keywords, args.match_mode, args.context or "")
    print(f"Cases found: {len(cases)}")
    print(f"Word list: {paths['docx']}")
    print(f"JSON list: {paths['json']}")
    print(f"CSV list: {paths['csv']}")


def cmd_report(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    archive = CaseArchive(cfg)
    archive.init_db()
    payload = load_keyword_list(args.list)
    cases = payload.get("cases", [])
    if args.case_numbers:
        wanted = {x.strip() for x in args.case_numbers.split(",") if x.strip()}
        cases = [c for c in cases if str(c.get("case_id", "")).strip() in wanted or str(c.get("case_key", "")).strip() in wanted]
    generator = ReportGenerator(cfg, archive)
    paths = generator.generate_for_cases(cases, payload.get("keywords", []), args.context or payload.get("context", ""))
    for path in paths:
        print(f"Report written: {path}")


def cmd_translate(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    if args.targets.strip().lower() == "all":
        targets = [code for code in EU_OFFICIAL_LANGUAGES if code != "en"]
    else:
        targets = [x.strip().lower() for x in args.targets.split(",") if x.strip()]
    out = ReportTranslator(cfg).translate_report(args.report, targets)
    for path in out:
        print(f"Translated: {path}")


def cmd_workflow(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    run_interactive(cfg)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Legal-linguistic EU case-law prototype")
    p.add_argument("--config", default=DEFAULT_CONFIG)
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("setup", help="Create config.yaml from the safe Windows profile")
    s.add_argument("--overwrite", action="store_true")
    s.set_defaults(func=cmd_setup)

    s = sub.add_parser("init", help="Initialise database and folders")
    s.set_defaults(func=cmd_init)

    s = sub.add_parser("doctor", help="Show local status and likely configuration problems")
    s.set_defaults(func=cmd_doctor)

    s = sub.add_parser("model-test", help="Send a one-line test to the configured analysis model")
    s.set_defaults(func=cmd_model_test)

    s = sub.add_parser("ingest", help="Ingest a local HTML/PDF/TXT folder or file")
    s.add_argument("path")
    s.add_argument("--lang", default="en")
    s.add_argument("--celex", default="")
    s.add_argument("--source-url", default="")
    s.set_defaults(func=cmd_ingest)

    s = sub.add_parser("collect", help="Collect CURIA pages by year range and ingest them")
    s.add_argument("--years", help="YYYY or YYYY-YYYY")
    s.add_argument("--start-year", type=int, default=2025)
    s.add_argument("--end-year", type=int, default=2025)
    s.add_argument("--courts", default="C")
    s.add_argument("--langs", default="en")
    s.add_argument("--max-case-number", type=int, default=None)
    s.add_argument("--max-saved", type=int, default=0)
    s.add_argument("--headed", action="store_true")
    s.add_argument("--manual", action="store_true")
    s.add_argument("--no-ingest", action="store_true")
    s.add_argument("--overwrite", action="store_true")
    s.set_defaults(func=cmd_collect)

    s = sub.add_parser("search", help="Create a keyword case list without report generation")
    s.add_argument("--keywords", required=True)
    s.add_argument("--separator", default=";")
    s.add_argument("--match-mode", choices=["all", "any"], default="any")
    s.add_argument("--context", default="")
    s.add_argument("--date-from", default="")
    s.add_argument("--date-to", default="")
    s.add_argument("--doc-type", default="")
    s.add_argument("--judge", default="")
    s.add_argument("--advocate-general", default="")
    s.add_argument("--lang", default="")
    s.add_argument("--case-id", default="")
    s.add_argument("--case-name", default="")
    s.add_argument("--ecli", default="")
    s.add_argument("--celex", default="")
    s.set_defaults(func=cmd_search)

    s = sub.add_parser("report", help="Generate English reports from a keyword list")
    s.add_argument("--list", required=True)
    s.add_argument("--context", default="")
    s.add_argument("--case-numbers", default="", help="Comma-separated case_id or case_key values")
    s.set_defaults(func=cmd_report)

    s = sub.add_parser("translate", help="Translate a generated Markdown report")
    s.add_argument("--report", required=True)
    s.add_argument("--targets", default="ro", help="Comma-separated EU language codes, or all")
    s.set_defaults(func=cmd_translate)

    s = sub.add_parser("workflow", help="Run the guided interactive workflow")
    s.set_defaults(func=cmd_workflow)

    return p


def main(argv: Sequence[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)

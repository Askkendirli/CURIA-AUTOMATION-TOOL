from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Iterable

from .constants import EU_OFFICIAL_LANGUAGES
from .ollama_client import OllamaClient


def split_text(text: str, max_chars: int) -> list[str]:
    chunks: list[str] = []
    current = ""
    for block in text.split("\n\n"):
        addition = ("\n\n" if current else "") + block
        if len(current) + len(addition) > max_chars and current:
            chunks.append(current)
            current = block
        else:
            current += addition
    if current:
        chunks.append(current)
    return chunks


class ReportTranslator:
    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg
        self.ollama = OllamaClient(cfg)

    def translate_report(self, report_path: str | Path, targets: Iterable[str]) -> list[str]:
        report_path = Path(report_path)
        text = report_path.read_text(encoding="utf-8")
        outputs: list[str] = []
        for lang in targets:
            if lang == "en":
                continue
            target_name = EU_OFFICIAL_LANGUAGES.get(lang, lang)
            translated = self.translate_text(text, "English", target_name)
            out_dir = Path(self.cfg["archive"]["report_dir"]) / "translations" / lang
            out_dir.mkdir(parents=True, exist_ok=True)
            out_path = out_dir / report_path.name
            out_path.write_text(translated, encoding="utf-8")
            outputs.append(str(out_path))
        return outputs

    def translate_text(self, text: str, source: str, target: str) -> str:
        model = self.cfg["llm"]["translation_model"]
        max_chars = int(self.cfg["translation"].get("chunk_chars", 2500))
        parts = split_text(text, max_chars)
        out: list[str] = []
        for index, part in enumerate(parts, start=1):
            prompt = (
                f"Translate the following legal-linguistic report from {source} to {target}. "
                "Preserve Markdown headings, case numbers, ECLI/CELEX identifiers, and table-like formatting. "
                "Do not add commentary. Return only the translation.\n\n"
                f"Part {index}/{len(parts)}:\n{part}"
            )
            out.append(self.ollama.chat(model, [{"role": "user", "content": prompt}], temperature=0.0).strip())
        return "\n\n".join(out)

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from bs4 import BeautifulSoup
from dateutil import parser as dateparser
from pypdf import PdfReader

from .utils import normalise_text

CASE_RE = re.compile(r"\b([CTF]\s*[-‑–—]\s*\d{1,4}/\d{2,4})\b", re.IGNORECASE)
ECLI_RE = re.compile(r"ECLI:EU:[A-Z]+:\d{4}:\d+", re.IGNORECASE)
CELEX_RE = re.compile(r"\b6\d{4}[A-Z]{2}\d{4}\b", re.IGNORECASE)
DATE_PATTERNS = [
    re.compile(r"\bdelivered on\s+(\d{1,2}\s+[A-Za-z]+\s+\d{4})", re.IGNORECASE),
    re.compile(r"\bof\s+(\d{1,2}\s+[A-Za-z]+\s+\d{4})\b", re.IGNORECASE),
    re.compile(r"\b(\d{1,2}\s+[A-Za-z]+\s+\d{4})\b", re.IGNORECASE),
]
DOC_TYPES = [
    ("AG Opinion", re.compile(r"OPINION OF ADVOCATE GENERAL", re.IGNORECASE)),
    ("Judgment", re.compile(r"JUDGMENT OF THE COURT|JUDGMENT OF THE GENERAL COURT|JUDGMENT", re.IGNORECASE)),
    ("Order", re.compile(r"ORDER OF THE COURT|ORDER OF THE GENERAL COURT|ORDER", re.IGNORECASE)),
]


def html_to_text(raw_html: str) -> str:
    soup = BeautifulSoup(raw_html or "", "lxml")
    for tag in soup(["script", "style", "noscript", "header", "footer", "nav"]):
        tag.decompose()
    text = soup.get_text("\n")
    if len(text.strip()) < 50:
        text = re.sub(r"(?is)<script.*?</script>", " ", raw_html or "")
        text = re.sub(r"(?is)<style.*?</style>", " ", text)
        text = re.sub(r"(?s)<[^>]+>", "\n", text)
    lines: list[str] = []
    for line in text.splitlines():
        line = normalise_text(line)
        if not line:
            continue
        low = line.lower()
        if low in {"html", "home", "language", "document", "procedure", "close", "cookies", "legal notice"}:
            continue
        lines.append(line)
    return normalise_text("\n".join(lines))


def extract_pdf(path: Path) -> str:
    reader = PdfReader(str(path))
    pages: List[str] = []
    for i, page in enumerate(reader.pages, start=1):
        try:
            text = page.extract_text() or ""
        except Exception as exc:
            text = f"[Text extraction error on page {i}: {exc}]"
        if text.strip():
            pages.append(f"[Page {i}]\n{text}")
    return normalise_text("\n\n".join(pages))


def extract_text(path: str | Path) -> str:
    p = Path(path)
    data = p.read_bytes()
    if not data:
        return ""
    if data[:4] == b"%PDF":
        return extract_pdf(p)
    raw = data.decode("utf-8", errors="ignore")
    suffix = p.suffix.lower()
    if suffix == ".pdf":
        return extract_pdf(p)
    if suffix in {".html", ".htm"} or "<html" in raw.lower() or "<!doctype" in raw.lower():
        return html_to_text(raw)
    if suffix in {".txt", ".md", ".xml", ".xhtml"}:
        return normalise_text(raw)
    return normalise_text(raw)


def _parse_delivery_date(src: str) -> str:
    for rx in DATE_PATTERNS:
        m = rx.search(src)
        if not m:
            continue
        value = m.group(1)
        try:
            return dateparser.parse(value, dayfirst=True).date().isoformat()
        except Exception:
            return value
    return ""


def _parse_named_role(src: str, role: str) -> str:
    role_rx = re.compile(role + r"\s*[:\-]?\s*([A-Z][A-Za-zÀ-ÖØ-öø-ÿ' .-]{2,80})", re.IGNORECASE)
    m = role_rx.search(src[:20000])
    if m:
        return normalise_text(m.group(1))[:80]
    return ""


def parse_metadata(
    text: str,
    filename: str = "",
    *,
    celex: Optional[str] = None,
    celex_hint: Optional[str] = None,
    lang: Optional[str] = None,
    source_url: Optional[str] = None,
    **_: Any,
) -> Dict[str, str]:
    if celex is None and celex_hint:
        celex = celex_hint
    head = normalise_text(text[:30000])
    src = head + "\n" + filename
    case_numbers: list[str] = []
    for m in CASE_RE.finditer(src):
        case = m.group(1).upper().replace(" ", "")
        case = re.sub(r"[-‑–—]", "-", case)
        if case not in case_numbers:
            case_numbers.append(case)
    ecli_m = ECLI_RE.search(src)
    celex_m = CELEX_RE.search(src)
    doc_type = "Document"
    for label, rx in DOC_TYPES:
        if rx.search(src):
            doc_type = label
            break
    lines = [ln.strip() for ln in head.splitlines() if ln.strip()]
    case_name = ""
    for i, ln in enumerate(lines[:220]):
        if re.search(r"\bv\b|\bversus\b", ln, re.IGNORECASE):
            case_name = " ".join(lines[max(0, i - 4): min(len(lines), i + 6)])
            case_name = re.sub(r"\s+", " ", case_name).strip()
            break
    if not case_name:
        for ln in lines[:90]:
            if len(ln) > 8 and not ln.lower().startswith(("language", "document", "procedure", "provisional text")):
                case_name = ln
                break
    if not case_name:
        case_name = Path(filename).stem.replace("_", " ").replace("-", " ").strip() or "Unknown case"
    return {
        "case_id": " ".join(case_numbers) if case_numbers else (celex or Path(filename).stem),
        "case_name": case_name,
        "case_numbers": ", ".join(case_numbers),
        "ecli": ecli_m.group(0).upper() if ecli_m else "",
        "celex": celex or (celex_m.group(0).upper() if celex_m else ""),
        "doc_type": doc_type,
        "delivery_date": _parse_delivery_date(src),
        "language": lang or "",
        "source_url": source_url or "",
        "judge": _parse_named_role(src, "Judge-Rapporteur"),
        "advocate_general": _parse_named_role(src, "Advocate General"),
    }

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List

from .archive import CaseArchive
from .ollama_client import OllamaClient
from .utils import now_stamp, slugify


REPORT_STRUCTURE = """
Use the following report structure:

# [Case ID] - [Short case name]

**Document type:** ...
**Date:** ...
**Keywords:** exactly 10 concise keywords
**Context supplied:** ...

## Abstract

## 1. Statement of Facts and Linguistic Problem

## 2. Procedural and Legal Context

## 3. Language Variation or Terminological Issue

## 4. Method of Interpretation

## 5. Outcome and Significance

## 6. Relevance to the Search Context

## Source Note
""".strip()


class ReportGenerator:
    def __init__(self, cfg: Dict[str, Any], archive: CaseArchive):
        self.cfg = cfg
        self.archive = archive
        self.ollama = OllamaClient(cfg)
        Path(cfg["archive"]["report_dir"]).mkdir(parents=True, exist_ok=True)

    def generate_for_cases(self, cases: Iterable[Dict[str, Any]], keywords: list[str], context: str) -> list[str]:
        paths: list[str] = []
        max_cases = int(self.cfg["reports"].get("max_cases_per_batch", 3))
        for i, case in enumerate(cases):
            if i >= max_cases:
                break
            paths.append(self.generate_one(case, keywords, context))
        return paths

    def generate_one(self, case: Dict[str, Any], keywords: list[str], context: str) -> str:
        max_chars = int(self.cfg["reports"].get("source_chars_per_case", 12000))
        source = self.archive.get_case_chunks(case["case_key"], max_chars=max_chars)
        model = self.cfg["llm"]["analysis_model"]
        prompt = f"""
A concise legal-linguistic report must be prepared from the supplied source excerpts only.
No fact may be invented. If a detail is not present in the excerpts, state that it is not established in the supplied excerpts.
The expected reader is a linguist or legal linguist rather than a programmer.

Search keywords: {', '.join(keywords)}
Brief context: {context or 'none'}
Case metadata: {json.dumps({k: case.get(k, '') for k in ['case_id','case_name','doc_type','delivery_date','ecli','celex']}, ensure_ascii=False)}

{REPORT_STRUCTURE}

Target length: {self.cfg['reports'].get('target_words_min', 850)}-{self.cfg['reports'].get('target_words_max', 1200)} words.

Source excerpts:
{source}
""".strip()
        output = self.ollama.chat(
            model,
            [
                {"role": "system", "content": "A careful EU legal-linguistic research assistant writes only grounded, concise reports."},
                {"role": "user", "content": prompt},
            ],
        ).strip()
        report_dir = Path(self.cfg["archive"]["report_dir"]) / "en"
        report_dir.mkdir(parents=True, exist_ok=True)
        filename = slugify(f"{case.get('case_id','case')}_{case.get('doc_type','document')}_{'_'.join(keywords[:5])}_{now_stamp()}", 180) + ".md"
        path = report_dir / filename
        path.write_text(output, encoding="utf-8")
        return str(path)

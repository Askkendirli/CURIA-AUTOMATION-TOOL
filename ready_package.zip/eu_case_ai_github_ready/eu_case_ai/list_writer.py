from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List

from docx import Document
from docx.shared import Inches

from .utils import now_stamp, slugify


def write_keyword_list(root: str | Path, keywords: list[str], match_mode: str, filters: Dict[str, str], context: str, cases: List[Dict[str, Any]]) -> Dict[str, str]:
    list_root = Path(root)
    list_root.mkdir(parents=True, exist_ok=True)
    name = f"keyword_list_{now_stamp()}_{slugify('_'.join(keywords), 50)}"
    json_path = list_root / f"{name}.json"
    csv_path = list_root / f"{name}.csv"
    docx_path = list_root / f"{name}.docx"

    payload = {
        "list_name": name,
        "created_at": now_stamp(),
        "keywords": keywords,
        "match_mode": match_mode,
        "filters": filters,
        "context": context,
        "cases": cases,
    }
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    fields = ["case_key", "case_id", "case_name", "doc_type", "delivery_date", "ecli", "celex", "language", "path"]
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for case in cases:
            writer.writerow({k: case.get(k, "") for k in fields})

    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.7)
    section.right_margin = Inches(0.7)
    doc.add_heading("Keyword Case List", 0)
    doc.add_paragraph(f"Keywords: {', '.join(keywords)}")
    doc.add_paragraph(f"Match mode: {match_mode}")
    doc.add_paragraph(f"Context: {context or 'No context supplied; no LLM report generation was required.'}")
    doc.add_paragraph(f"Number of cases: {len(cases)}")

    table = doc.add_table(rows=1, cols=6)
    table.style = "Table Grid"
    headers = ["No.", "Case", "Date", "Type", "Name", "Source"]
    for idx, header in enumerate(headers):
        table.rows[0].cells[idx].text = header
    for i, case in enumerate(cases, start=1):
        cells = table.add_row().cells
        cells[0].text = str(i)
        cells[1].text = case.get("case_id", "")
        cells[2].text = case.get("delivery_date", "")
        cells[3].text = case.get("doc_type", "")
        cells[4].text = case.get("case_name", "")[:280]
        cells[5].text = case.get("path", "")
    doc.add_paragraph("Machine-readable copies are stored as JSON and CSV beside this Word file.")
    doc.save(docx_path)

    return {"name": name, "json": str(json_path), "csv": str(csv_path), "docx": str(docx_path)}


def load_keyword_list(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    if p.suffix.lower() == ".json":
        return json.loads(p.read_text(encoding="utf-8"))
    if p.suffix.lower() == ".csv":
        with p.open("r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
        return {"list_name": p.stem, "keywords": [], "match_mode": "any", "context": "", "cases": rows}
    raise ValueError("Imported lists must use JSON or CSV format.")

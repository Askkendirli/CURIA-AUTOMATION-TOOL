from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import yaml

DEFAULT_CONFIG = "config.yaml"
SAFE_CONFIG = "config.windows.safe.yaml"


def load_config(path: str | Path = DEFAULT_CONFIG) -> Dict[str, Any]:
    cfg_path = Path(path)
    if not cfg_path.exists():
        safe = Path(SAFE_CONFIG)
        if safe.exists():
            cfg_path = safe
        else:
            raise FileNotFoundError(f"Configuration file not found: {path}")
    with cfg_path.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    cfg["_config_path"] = str(cfg_path)
    return cfg


def write_config(cfg: Dict[str, Any], path: str | Path = DEFAULT_CONFIG) -> None:
    with Path(path).open("w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)


def path_from_config(cfg: Dict[str, Any], section: str, key: str) -> Path:
    return Path(cfg[section][key])


def prepare_directories(cfg: Dict[str, Any]) -> None:
    for key in ["raw_dir", "text_dir", "manifest_dir", "list_dir", "report_dir"]:
        Path(cfg["archive"][key]).mkdir(parents=True, exist_ok=True)
    Path(cfg["archive"]["database"]).parent.mkdir(parents=True, exist_ok=True)

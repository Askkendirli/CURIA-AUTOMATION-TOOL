from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any, Dict

from .archive import CaseArchive
from .ollama_client import OllamaClient, OllamaError


def doctor(cfg: Dict[str, Any]) -> str:
    archive = CaseArchive(cfg)
    archive.init_db()
    status = archive.status()
    lines = []
    lines.append(f"Configuration: {cfg.get('_config_path', 'config.yaml')}")
    lines.append(f"Archive database: {cfg['archive']['database']}")
    lines.append(f"Documents indexed: {status['documents']}")
    lines.append(f"Cases indexed: {status['cases']}")
    lines.append(f"Chunks indexed: {status['chunks']}")
    lines.append(f"Keyword lists: {status['keyword_lists']}")
    lines.append(f"Ollama URL: {cfg['llm']['ollama_url']}")
    lines.append(f"Analysis model: {cfg['llm']['analysis_model']}")
    lines.append(f"Translation model: {cfg['llm']['translation_model']}")
    lines.append(f"num_ctx: {cfg['llm'].get('num_ctx')} | think: {cfg['llm'].get('think')} | keep_alive: {cfg['llm'].get('keep_alive')}")
    lines.append(f"Playwright available: {'yes' if shutil.which('playwright') else 'check via python -m playwright install chromium'}")
    try:
        tags = OllamaClient(cfg).tags()
        names = [m.get("name", "") for m in tags.get("models", [])]
        lines.append("Installed Ollama models:")
        for name in names:
            label = []
            if name == cfg['llm']['analysis_model']:
                label.append("analysis")
            if name == cfg['llm']['translation_model']:
                label.append("translation")
            suffix = f"  [{' + '.join(label)}]" if label else ""
            lines.append(f"  - {name}{suffix}")
        if cfg['llm']['analysis_model'] not in names:
            lines.append(f"WARNING: analysis model is not installed: ollama pull {cfg['llm']['analysis_model']}")
        if cfg['llm']['translation_model'] not in names:
            lines.append(f"WARNING: translation model is not installed: ollama pull {cfg['llm']['translation_model']}")
    except OllamaError as exc:
        lines.append(f"Ollama check failed: {exc}")
    return "\n".join(lines)


def quick_model_test(cfg: Dict[str, Any]) -> str:
    client = OllamaClient(cfg)
    model = cfg["llm"]["analysis_model"]
    try:
        response = client.chat(model, [{"role": "user", "content": "Respond with OK only."}], temperature=0.0)
        return f"Model test succeeded: {response.strip()[:200]}"
    except Exception as exc:
        return f"Model test failed: {exc}"

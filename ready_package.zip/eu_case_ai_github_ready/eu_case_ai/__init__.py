"""Local legal-linguistic EU case-law analysis prototype."""

__version__ = "0.2.0-windows-safe"
